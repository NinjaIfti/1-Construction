

<?php $__env->startSection('content'); ?>
<div class="animate-fadeIn">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl md:text-2xl font-bold"><?php echo e($contractor->name); ?>'s Documents</h2>
        <a href="<?php echo e(route('admin.documents.upload')); ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
            <i class="fas fa-file-upload mr-2"></i> Upload Document
        </a>
    </div>
    
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center mb-4">
            <form method="GET" action="<?php echo e(route('admin.documents.folders')); ?>" class="flex items-center">
                <select class="border rounded px-4 py-2 mr-2" id="folderContractorSelect" name="contractor_id" onchange="this.form.submit()">
                    <option value="">Select Contractor</option>
                    <?php $__currentLoopData = $contractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractorOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($contractorOption->id); ?>" <?php if($contractor->id == $contractorOption->id): ?> selected <?php endif; ?>>
                            <?php echo e($contractorOption->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
            
            <form method="POST" action="<?php echo e(route('admin.documents.create-folder')); ?>" class="flex items-center ml-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="contractor_id" value="<?php echo e($contractor->id); ?>">
                <input type="text" name="folder_name" placeholder="New folder name" class="border rounded px-4 py-2 mr-2" required>
                <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded">
                    <i class="fas fa-folder-plus mr-1"></i> Create Folder
                </button>
            </form>
        </div>
        
        <!-- Document folder structure -->
        <div class="mt-6">
            <h3 class="text-lg font-medium mb-4">Root Folders</h3>
            
            <?php if($rootFolders->isEmpty()): ?>
                <div class="text-gray-500 p-4 bg-gray-50 rounded">
                    No folders found. Create a folder to get started.
                </div>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $rootFolders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4 hover:bg-gray-50">
                            <a href="<?php echo e(route('admin.documents.folder', $folder)); ?>" class="flex items-start">
                                <div class="text-yellow-500 mr-3">
                                    <i class="fas fa-folder fa-2x"></i>
                                </div>
                                <div>
                                    <h4 class="font-medium"><?php echo e($folder->name); ?></h4>
                                    <div class="text-sm text-gray-500">
                                        <?php echo e($folder->subfolders->count()); ?> subfolder(s), 
                                        <?php echo e($folder->documents->count()); ?> document(s)
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Recent Documents Section -->
        <div class="mt-8">
            <h3 class="text-lg font-medium mb-4">Recent Documents</h3>
            
            <?php
                $recentDocuments = \App\Models\Document::where('contractor_id', $contractor->id)
                    ->orderBy('created_at', 'desc')
                    ->limit(5)
                    ->get();
            ?>
            
            <?php if($recentDocuments->isEmpty()): ?>
                <div class="text-gray-500 p-4 bg-gray-50 rounded">
                    No documents found.
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Document Name</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Folder</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Uploaded On</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $recentDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($document->name); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($document->file_type); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($document->folder): ?>
                                            <?php echo e($document->folder->name); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($document->document_status === 'approved'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Approved</span>
                                        <?php elseif($document->document_status === 'pending' || $document->document_status === null): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Pending</span>
                                        <?php elseif($document->document_status === 'rejected'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Rejected</span>
                                        <?php else: ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800"><?php echo e($document->document_status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($document->created_at->format('M d, Y')); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="<?php echo e(route('admin.documents.preview', $document)); ?>" class="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 px-3 py-1 rounded text-sm mr-2" target="_blank">
                                            <i class="fas fa-eye mr-1"></i> View
                                        </a>
                                        <a href="<?php echo e(route('admin.documents.download', $document)); ?>" class="bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-1 rounded text-sm">
                                            <i class="fas fa-download mr-1"></i> Download
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\GitHub\1 Construction\resources\views/layouts/admin/documents/folders.blade.php ENDPATH**/ ?>