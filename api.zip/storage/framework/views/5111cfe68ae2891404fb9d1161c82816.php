<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contractor Solutions Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
</head>
<body class="bg-gray-100">
  <div x-data="{ 
    sidebarOpen: false,
    activeTab: '<?php echo e(str_contains(Route::currentRouteName(), "verifications") ? "admin.verifications.index" : Route::currentRouteName()); ?>',
    uploadDragActive: false,
    notifications: [
      { text: 'New permit request', date: 'Apr 22' },
      { text: 'Apdrest updated', date: 'Apr 21' },
      { text: 'Phonicles approved', date: 'Apr 20' }
    ],
    projectStatuses: [
      { name: 'New notifications', date: 'Apr 12', status: '' },
      { name: 'Site-Development', date: 'Apr 23', status: '' },
      { name: 'Electrical Work', date: '', status: 'awaiting' },
      { name: 'Plumbing Installation', date: '', status: 'approved' },
      { name: 'Interior Remodel', date: '', status: 'pending' },
      { name: 'Roof Replacement', date: '', status: 'awaiting' }
    ],
    dropdownOpen: false,
    contractors: [],
    loadContractors() {
      fetch('/admin/api/dashboard/contractors')
        .then(response => response.json())
        .then(data => {
          this.contractors = data.recent || [];
        })
        .catch(error => {
          console.error('Error loading contractors:', error);
          this.contractors = [];
        });
    }
  }" 
  x-init="loadContractors()" 
  class="min-h-screen">
    <div class="flex flex-col lg:flex-row gap-6 p-4 md:p-6">
      <!-- Admin Dashboard Panel -->
      <div class="w-full lg:w-full bg-white rounded-lg shadow-md overflow-hidden">
        <!-- Header -->
        <div class="bg-gray-900 text-white p-4 flex justify-between items-center">
          <div class="flex items-center">
            <a href="/" class="flex items-center">
              <span class="text-red-600 text-3xl md:text-4xl font-bold">1</span>
              <div class="ml-2">
                <div class="text-lg md:text-xl font-bold">CONTRACTOR</div>
                <div class="text-xl md:text-2xl font-bold -mt-1">SOLUTIONS</div>
              </div>
            </a>
          </div>
          <div x-data="{ dropdownOpen: false }" class="relative">
            <div class="flex items-center">
              <span class="mr-2">Admin</span>
              <div @click="dropdownOpen = !dropdownOpen" class="w-8 h-8 md:w-10 md:h-10 bg-gray-300 rounded-full flex items-center justify-center cursor-pointer">
                <i class="fas fa-user text-gray-600"></i>
              </div>
            </div>

            <!-- Dropdown menu -->
            <div x-show="dropdownOpen" 
                 @click.away="dropdownOpen = false" 
                 class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
              <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                <i class="fas fa-cog mr-2"></i> Profile Settings
              </a>
              <div class="border-t border-gray-100 my-1"></div>
              <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100">
                  <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </button>
              </form>
            </div>
          </div>
        </div>

        <!-- Mobile menu button -->
        <div class="lg:hidden bg-gray-900 text-white px-4 py-2">
          <button @click="sidebarOpen = !sidebarOpen" class="flex items-center text-white focus:outline-none">
            <i class="fas fa-bars mr-2"></i> Menu
          </button>
        </div>

        <div class="flex flex-col lg:flex-row">
          <!-- Sidebar for mobile (collapsible) -->
          <div 
            class="lg:hidden bg-gray-900 text-white overflow-hidden transition-all duration-300"
            :class="sidebarOpen ? 'max-h-screen' : 'max-h-0'"
          >
            <div class="p-4">
              <div class="flex flex-col space-y-6">
                <a href="<?php echo e(route('admin.dashboard')); ?>" @click="activeTab = 'admin.dashboard'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'admin.dashboard' ? 'bg-blue-900' : ''">
                  <i class="fas fa-home mr-3"></i>
                  <span>Dashboard</span>
                </a>
                <button @click="activeTab = 'permits'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'permits' ? 'bg-blue-900' : ''">
                  <i class="fas fa-file-alt mr-3"></i>
                  <span>Permit Requests</span>
                </button>
                <a href="<?php echo e(route('admin.documents.index')); ?>" @click="activeTab = 'documents'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'documents' ? 'bg-blue-900' : ''">
                  <i class="fas fa-folder mr-3"></i>
                  <span>Documents</span>
                </a>
                <a href="<?php echo e(route('admin.contractors.index')); ?>" @click="activeTab = 'contractors.index'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'contractors.index' ? 'bg-blue-900' : ''">
                  <i class="fas fa-users mr-3"></i>
                  <span>Contractors</span>
                </a>
                <a href="<?php echo e(route('admin.verifications.index')); ?>" @click="activeTab = 'admin.verifications.index'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'admin.verifications.index' || activeTab.includes('verifications') ? 'bg-blue-900' : ''">
                  <i class="fas fa-check-circle mr-3"></i>
                  <span>Verifications</span>
                </a>
                <button @click="activeTab = 'notifications'; sidebarOpen = false" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'notifications' ? 'bg-blue-900' : ''">
                  <i class="fas fa-bell mr-3"></i>
                  <span>Notifications</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Sidebar for desktop -->
          <div class="hidden lg:block w-1/5 bg-gray-900 text-white min-h-screen">
            <div class="p-4">
              <div class="flex flex-col space-y-6">
                <a href="<?php echo e(route('admin.dashboard')); ?>" @click="activeTab = 'admin.dashboard'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'admin.dashboard' ? 'bg-blue-900' : ''">
                  <i class="fas fa-home mr-3"></i>
                  <span>Dashboard</span>
                </a>
                <button @click="activeTab = 'permits'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'permits' ? 'bg-blue-900' : ''">
                  <i class="fas fa-file-alt mr-3"></i>
                  <span>Permit Requests</span>
                </button>
                <a href="<?php echo e(route('admin.documents.index')); ?>" @click="activeTab = 'documents'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'documents' ? 'bg-blue-900' : ''">
                  <i class="fas fa-folder mr-3"></i>
                  <span>Documents</span>
                </a>
                <a href="<?php echo e(route('admin.contractors.index')); ?>" @click="activeTab = 'contractors.index'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'contractors.index' ? 'bg-blue-900' : ''">
                  <i class="fas fa-users mr-3"></i>
                  <span>Contractors</span>
                </a>
                <a href="<?php echo e(route('admin.verifications.index')); ?>" @click="activeTab = 'admin.verifications.index'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'admin.verifications.index' || activeTab.includes('verifications') ? 'bg-blue-900' : ''">
                  <i class="fas fa-check-circle mr-3"></i>
                  <span>Verifications</span>
                </a>
                <button @click="activeTab = 'notifications'" class="flex items-center hover:bg-gray-800 p-2 rounded-md transition" :class="activeTab === 'notifications' ? 'bg-blue-900' : ''">
                  <i class="fas fa-bell mr-3"></i>
                  <span>Notifications</span>
                </button>
              </div>
            </div>
          </div>

          <!-- Main Content -->
          <div class="w-full lg:w-4/5 p-4 md:p-6">
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php if(Route::currentRouteName() == 'admin.dashboard'): ?>
            <!-- Dashboard Tab -->
            <div x-show="activeTab === 'admin.dashboard'">
              <h2 class="text-xl md:text-2xl font-bold mb-6">Admin Dashboard</h2>
              
              <!-- Permit Requests Section -->
              <div class="mb-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div class="border rounded-lg p-4">
                    <h3 class="font-bold mb-4">Permit Requests</h3>
                    <div class="flex space-x-4 md:space-x-6 justify-between md:justify-start">
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold">12</div>
                        <div class="text-xs md:text-sm text-gray-600">New</div>
                      </div>
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold">8</div>
                        <div class="text-xs md:text-sm text-gray-600">In Review</div>
                      </div>
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold">5</div>
                        <div class="text-xs md:text-sm text-gray-600">Approved</div>
                      </div>
                    </div>
                  </div>
                  
                  <!-- Documents Section -->
                  <div class="border rounded-lg p-4">
                    <h3 class="font-bold mb-4">
                      Documents
                      <a href="<?php echo e(route('admin.documents.index')); ?>" class="text-sm text-blue-500 hover:underline ml-2">View All</a>
                    </h3>
                    <div class="flex space-x-4 md:space-x-6 justify-between md:justify-start">
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold"><?php echo e($documentsCount ?? 0); ?></div>
                        <div class="text-xs md:text-sm text-gray-600">Total</div>
                      </div>
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold"><?php echo e($pendingDocumentsCount ?? 0); ?></div>
                        <div class="text-xs md:text-sm text-gray-600">Pending</div>
                      </div>
                      <div class="text-center">
                        <div class="text-2xl md:text-3xl font-bold"><?php echo e($todayDocumentsCount ?? 0); ?></div>
                        <div class="text-xs md:text-sm text-gray-600">Today</div>
                      </div>
                    </div>
                    
                    <!-- Upload documents button -->
                    <div class="mt-4">
                      <button class="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm" 
                              @click="document.getElementById('dashboardUpload').click()">
                        <i class="fas fa-cloud-upload-alt mr-2"></i> Upload Document
                      </button>
                      <input type="file" id="dashboardUpload" class="hidden">
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Contractor Directory -->
              <div class="mb-6">
                <div class="border rounded-lg p-4">
                  <h3 class="font-bold mb-4">
                    Contractor Directory
                    <a href="<?php echo e(route('admin.contractors.index')); ?>" class="text-sm text-blue-500 hover:underline ml-2">View All</a>
                  </h3>
                  <div class="space-y-2">
                    <template x-for="contractor in contractors" :key="contractor.id">
                      <div class="flex justify-between items-center p-2 hover:bg-gray-50 rounded">
                        <div class="flex items-center">
                          <div class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                            <i class="fas fa-building text-gray-500"></i>
                          </div>
                          <div>
                            <div x-text="contractor.company_name" class="font-medium"></div>
                            <div x-text="contractor.name" class="text-xs text-gray-500"></div>
                          </div>
                        </div>
                        <a :href="'/admin/contractors/' + contractor.id" class="text-blue-500 hover:underline">
                          <i class="fas fa-eye"></i>
                        </a>
                      </div>
                    </template>
                    
                    <div x-show="contractors.length === 0" class="text-center py-4 text-gray-500">
                      No contractors found
                    </div>
                  </div>
                </div>
              </div>
              
              <!-- Notifications Section -->
              <div class="mb-6">
                <div class="border rounded-lg p-4">
                  <h3 class="font-bold mb-4">Notifications</h3>
                  <div class="space-y-2">
                    <template x-for="notification in notifications" :key="notification.text">
                      <div class="flex justify-between hover:bg-gray-50 p-2 rounded cursor-pointer" @click="alert('Viewing notification: ' + notification.text)">
                        <div x-text="notification.text"></div>
                        <div class="text-xs md:text-sm text-gray-600" x-text="notification.date"></div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
              
              <!-- Project Status -->
              <div>
                <h3 class="font-bold mb-4">Project Status</h3>
                <div class="space-y-3">
                  <template x-for="project in projectStatuses" :key="project.name">
                    <div class="flex justify-between items-center hover:bg-gray-50 p-2 rounded cursor-pointer" @click="alert('Project details: ' + project.name)">
                      <div x-text="project.name"></div>
                      <div class="flex items-center">
                        <template x-if="project.date">
                          <div class="text-xs md:text-sm text-gray-600 mr-2" x-text="project.date"></div>
                        </template>
                        <template x-if="project.status === 'awaiting'">
                          <div class="text-xs md:text-sm bg-yellow-100 px-2 py-1 rounded">Awaiting</div>
                        </template>
                        <template x-if="project.status === 'approved'">
                          <div class="text-xs md:text-sm bg-green-100 px-2 py-1 rounded">Approved</div>
                        </template>
                        <template x-if="project.status === 'pending'">
                          <div class="text-xs md:text-sm bg-gray-100 px-2 py-1 rounded">Pending</div>
                        </template>
                      </div>
                    </div>
                  </template>
                </div>
              </div>
            </div>
            <?php endif; ?>

          
            
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Animated styles -->
  <style>
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    .animate-fadeIn {
      animation: fadeIn 0.3s ease-in-out;
    }
  </style>
</body>
</html><?php /**PATH S:\GitHub\1 Construction\resources\views/layouts/admin/dashboard.blade.php ENDPATH**/ ?>