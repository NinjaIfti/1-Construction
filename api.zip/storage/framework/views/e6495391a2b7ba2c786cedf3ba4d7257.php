

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <div class="mb-4 flex items-center">
        <a href="<?php echo e(URL::previous()); ?>" class="bg-gray-500 text-white px-3 py-1 rounded mr-4">
            <i class="fas fa-arrow-left mr-1"></i> Back
        </a>
        <h2 class="text-xl font-bold"><?php echo e($document->name); ?></h2>
        <div class="ml-auto">
            <a href="<?php echo e(route('client.documents.download', $document)); ?>" class="bg-blue-500 text-white px-3 py-1 rounded">
                <i class="fas fa-download mr-1"></i> Download
            </a>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-4">
        <?php if($document->description): ?>
            <div class="mb-4 text-gray-700">
                <strong>Description:</strong> <?php echo e($document->description); ?>

            </div>
        <?php endif; ?>
        
        <div class="mb-2 text-sm text-gray-600">
            Uploaded on <?php echo e($document->created_at->format('M d, Y')); ?> | <?php echo e($document->formatted_file_size); ?>

        </div>
        
        <div class="border rounded-lg p-4 flex justify-center">
            <img src="<?php echo e($url); ?>" alt="<?php echo e($document->name); ?>" class="max-w-full max-h-screen object-contain">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH S:\GitHub\1 Construction\resources\views/layouts/client/documents/preview_image.blade.php ENDPATH**/ ?>